jQuery(document).ready(function($) {
								var icons = {
									header: "ts-header",
									activeHeader: "ts-active-header"
									};
									$( ".ts-acordion-366" ).accordion({
										icons: icons,
										active:0,
										collapsible: true
									});
							});
							
jQuery(document).ready(function($) {
									var icons = {
										header: "fa fa-caret-right",
										activeHeader: "fa fa-caret-down"
										};
										$( ".ts-acordion-711" ).accordion({
											icons: icons,
											active:0,
											collapsible: true
										});
								});