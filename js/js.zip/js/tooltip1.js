	<div class='bg-parallax gambit-bg-parallax parallax' data-bg-align='' data-direction='none' data-mute='' data-opacity='' data-velocity='-0.3' data-mobile-enabled='' data-break-parents='' data-bg-height='' data-bg-width='' data-bg-image='' data-bg-repeat='false'></div>
		<div  class="bg_parallax  vc_custom_1420861963111">
		<div class="container">
		<div class="row">
			<div class="col-sm-12  ">
				<div class="ts-wrapper">
					<div class="ts-fa-list">
					<div class="ts-social-style3"><a class="ts-style-icon-fa-rss" data-toggle="tooltip" data-placement="top" title="RSS" href="#"><i class="fa fa-rss"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-rss").hover(function(){
									jQuery(this).css("background","#ff8300");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-envelope" data-toggle="tooltip" data-placement="top" title="Email" href="#"><i class="fa fa-envelope"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-envelope").hover(function(){
									jQuery(this).css("background","#666666");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-facebook" data-toggle="tooltip" data-placement="top" title="Facebook" href="#"><i class="fa fa-facebook"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-facebook").hover(function(){
									jQuery(this).css("background","#3B5895");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-twitter" data-toggle="tooltip" data-placement="top" title="Twitter" href="#"><i class="fa fa-twitter"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-twitter").hover(function(){
									jQuery(this).css("background","#40BFF5");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-google" data-toggle="tooltip" data-placement="top" title="Googlle" href="#"><i class="fa fa-google"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-google").hover(function(){
									jQuery(this).css("background","#3876E5");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-google-plus" data-toggle="tooltip" data-placement="top" title="Google+" href="#"><i class="fa fa-google-plus"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-google-plus").hover(function(){
									jQuery(this).css("background","#D44132");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-linkedin-square" data-toggle="tooltip" data-placement="top" title="Linkedin" href="#"><i class="fa fa-linkedin-square"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-linkedin-square").hover(function(){
									jQuery(this).css("background","#0077B5");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-instagram" data-toggle="tooltip" data-placement="top" title="Instagram" href="#"><i class="fa fa-instagram"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-instagram").hover(function(){
									jQuery(this).css("background","#0077B5");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-flickr" data-toggle="tooltip" data-placement="top" title="flickr" href="#"><i class="fa fa-flickr"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-flickr").hover(function(){
									jQuery(this).css("background","#0063DB");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-vimeo-square" data-toggle="tooltip" data-placement="top" title="Vimeo" href="#"><i class="fa fa-vimeo-square"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-vimeo-square").hover(function(){
									jQuery(this).css("background","#20B9EB");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-youtube" data-toggle="tooltip" data-placement="top" title="YouTube" href="#"><i class="fa fa-youtube"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-youtube").hover(function(){
									jQuery(this).css("background","#CD332D");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-yahoo" data-toggle="tooltip" data-placement="top" title="Yahoo" href="#"><i class="fa fa-yahoo"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-yahoo").hover(function(){
									jQuery(this).css("background","#7E3585");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-delicious" data-toggle="tooltip" data-placement="top" title="Delicious" href="#"><i class="fa fa-delicious"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-delicious").hover(function(){
									jQuery(this).css("background","#3274D1");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-pinterest" data-toggle="tooltip" data-placement="top" title="Pinterest" href="#"><i class="fa fa-pinterest"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-pinterest").hover(function(){
									jQuery(this).css("background","#CD2B30");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-stumbleupon" data-toggle="tooltip" data-placement="top" title="StumbleUpon" href="#"><i class="fa fa-stumbleupon"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-stumbleupon").hover(function(){
									jQuery(this).css("background","#EA4B24");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-dribbble" data-toggle="tooltip" data-placement="top" title="Dribbble" href="#"><i class="fa fa-dribbble"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-dribbble").hover(function(){
									jQuery(this).css("background","#EA4C89");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-behance" data-toggle="tooltip" data-placement="top" title="Behance" href="#"><i class="fa fa-behance"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-behance").hover(function(){
									jQuery(this).css("background","#1769FF");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script><a class="ts-style-icon-fa-tumblr" data-toggle="tooltip" data-placement="top" title="Tumblr" href="#"><i class="fa fa-tumblr"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-tumblr").hover(function(){
									jQuery(this).css("background","#395975");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-github-alt" data-toggle="tooltip" data-placement="top" title="Github" href="#"><i class="fa fa-github-alt"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-github-alt").hover(function(){
									jQuery(this).css("background","#272426");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-lastfm" data-toggle="tooltip" data-placement="top" title="Lastfm" href="#"><i class="fa fa-lastfm"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-lastfm").hover(function(){
									jQuery(this).css("background","#D51007");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-skype" data-toggle="tooltip" data-placement="top" title="Skype" href="#"><i class="fa fa-skype"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-skype").hover(function(){
									jQuery(this).css("background","#00AFF0");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-wordpress" data-toggle="tooltip" data-placement="top" title="WordPress" href="#"><i class="fa fa-wordpress"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-wordpress").hover(function(){
									jQuery(this).css("background","#21759B");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-dropbox" data-toggle="tooltip" data-placement="top" title="Dropbox" href="#"><i class="fa fa-dropbox"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-dropbox").hover(function(){
									jQuery(this).css("background","#007EE5");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-pinterest-square" data-toggle="tooltip" data-placement="top" title="Pinterest" href="#"><i class="fa fa-pinterest-square"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-pinterest-square").hover(function(){
									jQuery(this).css("background","#E41F11");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-deviantart" data-toggle="tooltip" data-placement="top" title="DeviantART" href="#"><i class="fa fa-deviantart"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-deviantart").hover(function(){
									jQuery(this).css("background","#5C7061");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-share-alt" data-toggle="tooltip" data-placement="top" title="Share" href="#"><i class="fa fa-share-alt"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-share-alt").hover(function(){
									jQuery(this).css("background","#018752");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-reddit" data-toggle="tooltip" data-placement="top" title="Reddit" href="#"><i class="fa fa-reddit"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-reddit").hover(function(){
									jQuery(this).css("background","#FA5112");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-apple" data-toggle="tooltip" data-placement="top" title="Apple" href="#"><i class="fa fa-apple"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-apple").hover(function(){
									jQuery(this).css("background","#9FA6A8");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-windows" data-toggle="tooltip" data-placement="top" title="Windows" href="#"><i class="fa fa-windows"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-windows").hover(function(){
									jQuery(this).css("background","#00BDF6");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-android" data-toggle="tooltip" data-placement="top" title="Android" href="#"><i class="fa fa-android"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-android").hover(function(){
									jQuery(this).css("background","#A4C639");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-xing" data-toggle="tooltip" data-placement="top" title="Xing" href="#"><i class="fa fa-xing"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-xing").hover(function(){
									jQuery(this).css("background","#0A7577");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-spotify" data-toggle="tooltip" data-placement="top" title="Spotify" href="#"><i class="fa fa-spotify"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-spotify").hover(function(){
									jQuery(this).css("background","#77B900");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-yelp" data-toggle="tooltip" data-placement="top" title="Yelp" href="#"><i class="fa fa-yelp"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-yelp").hover(function(){
									jQuery(this).css("background","#C93C27");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-soundcloud" data-toggle="tooltip" data-placement="top" title="Soundcloud" href="#"><i class="fa fa-soundcloud"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-soundcloud").hover(function(){
									jQuery(this).css("background","#FA6C14");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-cloud" data-toggle="tooltip" data-placement="top" title="Cloud" href="#"><i class="fa fa-cloud"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-cloud").hover(function(){
									jQuery(this).css("background","#959C9E");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-vk" data-toggle="tooltip" data-placement="top" title="VK" href="#"><i class="fa fa-vk"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-vk").hover(function(){
									jQuery(this).css("background","#476A91");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-at" data-toggle="tooltip" data-placement="top" title="At" href="#"><i class="fa fa-at"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-at").hover(function(){
									jQuery(this).css("background","#014B88");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-vine" data-toggle="tooltip" data-placement="top" title="Vine" href="#"><i class="fa fa-vine"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-vine").hover(function(){
									jQuery(this).css("background","#00B386");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-renren" data-toggle="tooltip" data-placement="top" title="Renren" href="#"><i class="fa fa-renren"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-renren").hover(function(){
									jQuery(this).css("background","#105BA3");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-paw" data-toggle="tooltip" data-placement="top" title="Paw" href="#"><i class="fa fa-paw"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-paw").hover(function(){
									jQuery(this).css("background","#2932E1");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-user" data-toggle="tooltip" data-placement="top" title="User" href="#"><i class="fa fa-user"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-user").hover(function(){
									jQuery(this).css("background","#999999");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-css3" data-toggle="tooltip" data-placement="top" title="CSS3" href="#"><i class="fa fa-css3"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-css3").hover(function(){
									jQuery(this).css("background","#129ED9");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-html5" data-toggle="tooltip" data-placement="top" title="HTML5" href="#"><i class="fa fa-html5"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-html5").hover(function(){
									jQuery(this).css("background","#F16529");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-bitbucket" data-toggle="tooltip" data-placement="top" title="Bitbucket" href="#"><i class="fa fa-bitbucket"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-bitbucket").hover(function(){
									jQuery(this).css("background","#013366");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-btc" data-toggle="tooltip" data-placement="top" title="BTC" href="#"><i class="fa fa-btc"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-btc").hover(function(){
									jQuery(this).css("background","#F7931A");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-joomla" data-toggle="tooltip" data-placement="top" title="Joomla" href="#"><i class="fa fa-joomla"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-joomla").hover(function(){
									jQuery(this).css("background","#1472B2");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-angellist" data-toggle="tooltip" data-placement="top" title="AngelList" href="#"><i class="fa fa-angellist"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-angellist").hover(function(){
									jQuery(this).css("background","#6A98CF");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-paypal" data-toggle="tooltip" data-placement="top" title="Paypal" href="#"><i class="fa fa-paypal"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-paypal").hover(function(){
									jQuery(this).css("background","#C5C5C5");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-cc-visa" data-toggle="tooltip" data-placement="top" title="Visa" href="#"><i class="fa fa-cc-visa"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-cc-visa").hover(function(){
									jQuery(this).css("background","#17BCE1");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-delicious" data-toggle="tooltip" data-placement="top" title="Dilicious" href="#"><i class="fa fa-delicious"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-delicious").hover(function(){
									jQuery(this).css("background","#3274D1");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-deviantart" data-toggle="tooltip" data-placement="top" title="Deviantart" href="#"><i class="fa fa-deviantart"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-deviantart").hover(function(){
									jQuery(this).css("background","#5F716F");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-digg" data-toggle="tooltip" data-placement="top" title="Dig" href="#"><i class="fa fa-digg"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-digg").hover(function(){
									jQuery(this).css("background","#1D1D1E");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-drupal" data-toggle="tooltip" data-placement="top" title="Drupal" href="#"><i class="fa fa-drupal"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-drupal").hover(function(){
									jQuery(this).css("background","#0C7BC2");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-ioxhost" data-toggle="tooltip" data-placement="top" title="IoxHost" href="#"><i class="fa fa-ioxhost"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-ioxhost").hover(function(){
									jQuery(this).css("background","#FAA829");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-linux" data-toggle="tooltip" data-placement="top" title="Linux" href="#"><i class="fa fa-linux"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-linux").hover(function(){
									jQuery(this).css("background","#F3BF00");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-maxcdn" data-toggle="tooltip" data-placement="top" title="MaxCDN" href="#"><i class="fa fa-maxcdn"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-maxcdn").hover(function(){
									jQuery(this).css("background","#97310E");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-slack" data-toggle="tooltip" data-placement="top" title="Slack" href="#"><i class="fa fa-slack"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-slack").hover(function(){
									jQuery(this).css("background","#83D2E1");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-trello" data-toggle="tooltip" data-placement="top" title="Trello" href="#"><i class="fa fa-trello"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-trello").hover(function(){
									jQuery(this).css("background","#1A6AA3");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-twitch" data-toggle="tooltip" data-placement="top" title="Twitch" href="#"><i class="fa fa-twitch"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-twitch").hover(function(){
									jQuery(this).css("background","#64459B");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-slideshare" data-toggle="tooltip" data-placement="top" title="Slideshare" href="#"><i class="fa fa-slideshare"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-slideshare").hover(function(){
									jQuery(this).css("background","#0CA8AA");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-stumbleupon" data-toggle="tooltip" data-placement="top" title="Stumbleupon" href="#"><i class="fa fa-stumbleupon"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-stumbleupon").hover(function(){
									jQuery(this).css("background","#EA4B24");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-stack-exchange" data-toggle="tooltip" data-placement="top" title="Stack Exchange" href="#"><i class="fa fa-stack-exchange"></i></a><script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-stack-exchange").hover(function(){
									jQuery(this).css("background","#205296");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						<a class="ts-style-icon-fa-stack-overflow" data-toggle="tooltip" data-placement="top" title="Stack Overflow" href="#"><i class="fa fa-stack-overflow"></i></a>
						<script>
								jQuery(document).ready(function(){
								  jQuery('[data-toggle="tooltip"]').tooltip();
								  jQuery("a.ts-style-icon-fa-stack-overflow").hover(function(){
									jQuery(this).css("background","#75845C");
									},function(){
									jQuery(this).css("background","transparent");
								  });
								});
						</script>
						</div>
				</div> 
			</div> 
		</div>
		</div>
		</div>
		</div>