jQuery(document).ready(function(){
										  jQuery(".ts-button-693 a.ts-style-button").hover(function(){
											jQuery(".ts-button-693 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-693 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-693 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-693 a.ts-style-button").css("background","#42454a");
											jQuery(".ts-button-693 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-693 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-633 a.ts-style-button").hover(function(){
											jQuery(".ts-button-633 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-633 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-633 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-633 a.ts-style-button").css("background","#42454a");
											jQuery(".ts-button-633 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-633 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-41 a.ts-style-button").hover(function(){
											jQuery(".ts-button-41 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-41 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-41 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-41 a.ts-style-button").css("background","#42454a");
											jQuery(".ts-button-41 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-41 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-185 a.ts-style-button").hover(function(){
											jQuery(".ts-button-185 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-185 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-185 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-185 a.ts-style-button").css("background","#f3f3f3");
											jQuery(".ts-button-185 a.ts-style-button").css("color","#000000");
											jQuery(".ts-button-185 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-599 a.ts-style-button").hover(function(){
											jQuery(".ts-button-599 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-599 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-599 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-599 a.ts-style-button").css("background","#f3f3f3");
											jQuery(".ts-button-599 a.ts-style-button").css("color","#000000");
											jQuery(".ts-button-599 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-383 a.ts-style-button").hover(function(){
											jQuery(".ts-button-383 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-383 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-383 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-383 a.ts-style-button").css("background","#f3f3f3");
											jQuery(".ts-button-383 a.ts-style-button").css("color","#000000");
											jQuery(".ts-button-383 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-894 a.ts-style-button").hover(function(){
											jQuery(".ts-button-894 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-894 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-894 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-894 a.ts-style-button").css("background","#ffffff");
											jQuery(".ts-button-894 a.ts-style-button").css("color","#252525");
											jQuery(".ts-button-894 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-548 a.ts-style-button").hover(function(){
											jQuery(".ts-button-548 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-548 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-548 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-548 a.ts-style-button").css("background","#ffffff");
											jQuery(".ts-button-548 a.ts-style-button").css("color","#000000");
											jQuery(".ts-button-548 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-341 a.ts-style-button").hover(function(){
											jQuery(".ts-button-341 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-341 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-341 a.ts-style-button").css("border-color","#fd4326");
											},function(){
											jQuery(".ts-button-341 a.ts-style-button").css("background","#ffffff");
											jQuery(".ts-button-341 a.ts-style-button").css("color","#252525");
											jQuery(".ts-button-341 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-245 a.ts-style-button").hover(function(){
											jQuery(".ts-button-245 a.ts-style-button").css("background","#252525");
											jQuery(".ts-button-245 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-245 a.ts-style-button").css("border-color","#252525");
											},function(){
											jQuery(".ts-button-245 a.ts-style-button").css("background","#55adff");
											jQuery(".ts-button-245 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-245 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-825 a.ts-style-button").hover(function(){
											jQuery(".ts-button-825 a.ts-style-button").css("background","#252525");
											jQuery(".ts-button-825 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-825 a.ts-style-button").css("border-color","#252525");
											},function(){
											jQuery(".ts-button-825 a.ts-style-button").css("background","#fd4326");
											jQuery(".ts-button-825 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-825 a.ts-style-button").css("border-color","#42454a");
										  });
										});

										jQuery(document).ready(function(){
										  jQuery(".ts-button-108 a.ts-style-button").hover(function(){
											jQuery(".ts-button-108 a.ts-style-button").css("background","#252525");
											jQuery(".ts-button-108 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-108 a.ts-style-button").css("border-color","#252525");
											},function(){
											jQuery(".ts-button-108 a.ts-style-button").css("background","#5fd33f");
											jQuery(".ts-button-108 a.ts-style-button").css("color","#ffffff");
											jQuery(".ts-button-108 a.ts-style-button").css("border-color","#42454a");
										  });
										});