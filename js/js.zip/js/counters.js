jQuery(document).ready(function($) {
						$('.circlestat-183').circliful();
						});

						jQuery(document).ready(function($) {
						$('.circlestat-479').circliful();
						});

						jQuery(document).ready(function($) {
						$('.circlestat-861').circliful();
						});

						jQuery(document).ready(function($) {
						$('.circlestat-171').circliful();
						});

						jQuery(document).ready(function($) {
						$('.circlestat-242').circliful();
						});

						jQuery(document).ready(function($) {
						$('.circlestat-327').circliful();
						});

						jQuery(document).ready(function($) {
						$('.circlestat-146').circliful();
						});

								jQuery(function($){
								 $('.ts-countdown-287').countdown('2015/05/01 10:30:20', function(event) {
									var ts_day = event.strftime('%-D');
									var ts_hour = event.strftime('%-H');
									var ts_minute = event.strftime('%-M');
									var ts_second = event.strftime('%-S');
									$('.day-287').html(ts_day);
									$('.hour-287').html(ts_hour);
									$('.minute-287').html(ts_minute);
									$('.second-287').html(ts_second);
							  });
							});

								jQuery(function($){
								 $('.ts-countdown-950').countdown('2015/05/01 10:30:20', function(event) {
									var ts_day = event.strftime('%-D');
									var ts_hour = event.strftime('%-H');
									var ts_minute = event.strftime('%-M');
									var ts_second = event.strftime('%-S');
									$('.day-950').html(ts_day);
									$('.hour-950').html(ts_hour);
									$('.minute-950').html(ts_minute);
									$('.second-950').html(ts_second);
							  });
							});